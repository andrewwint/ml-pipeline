# Lambda entry point
from genai_insights import handler